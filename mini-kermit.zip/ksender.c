#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "lib.h"

#define HOST "127.0.0.1"
#define PORT 10000

int main(int argc, char** argv) {

    init(HOST, PORT);

	//msg t, *y;
	kermit pack;
	FILE *f;

	int prev, i;
	char vid[MAXL];
	memset(vid, 0, MAXL);

	pack = make_S_pack ('S', MAXL, TIME, 0);

	printf(YELLOW "[SENDER]   Initializing ...\n" RESETCOLOR);

	prev = send_package(pack);

	if (prev >= 0)
		printf(BLUE "[SENDER]   Connection estabilished.\n" RESETCOLOR);
	else {printf(RED "[SENDER]   Transmission failed!\n" RESETCOLOR); return 0;}

	for (i = 1 ; i < argc ; i++) {

		// send F package for opening file:

		pack = make_pack((prev+1)%64, 'F', argv[i]);

		prev = send_package(pack);

		if (prev >= 0)
			printf("\n           File header sent.\n\n");
		else {	printf(RED "[SENDER]   Transmission failed!\n" RESETCOLOR); 
			return 0;
		}

		// send content:

		f = fopen(argv[i], "r");

		do {
			pack = make_pack((prev+1)%64, 'D', vid);  // make data pack, with no data	

			pack.len = fread(pack.data, 1, MAXL, f);  // read data from file

			prev = send_package(pack);		  // send

			if (prev >= 0)
				printf("           Package sent.\n\n");
			else {
				printf(RED "[SENDER]   Transmission failed!\n" RESETCOLOR); 
				return 0;
			}

		} while (pack.len > 0); // do this, while there is still data to read from file

		// send Z package for EOF:

		pack = make_pack((prev+1)%64, 'Z', vid);

		prev = send_package(pack);

		if (prev >= 0)
			printf("           File sent.\n\n");
		else {printf(RED "[SENDER]   Transmission failed!\n" RESETCOLOR); return 0;}

	}

	// send B package for end of transmission:

	pack = make_pack((prev+1)%64, 'B', vid);

	prev = send_package(pack);

	if (prev > 0) {
		printf("===========================================\n");
		printf(GREEN "[SENDER]   Transmission ended with success.\n" RESETCOLOR);
		printf("===========================================\n");
	}
	else {printf(RED "[SENDER] Transmission failed!\n" RESETCOLOR); return 0;}
    
    return 0;
}
