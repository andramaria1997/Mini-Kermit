#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "lib.h"

#define HOST "127.0.0.1"
#define PORT 10001

int main(int argc, char** argv) {

	msg *y, t;
	int contorNAK, contorLOST, prev;
	kermit recv, pack;
	char vid[MAXL];
	memset(vid, 0, MAXL);
	FILE *f;
	char filename[100] = "recv_";
	
	init(HOST, PORT);
	RESET(contorNAK); RESET(contorLOST);
	
	do {
		y = receive_message_timeout(5000);
		if (y == NULL) {
			printf(YELLOW "[RECEIVER] Waiting...\n" RESETCOLOR);
			contorLOST--;
		}
		else {	memset(&recv, 0, sizeof(kermit));
			memcpy(&recv, y->payload, y->len);
			if (crc16_ccitt(&recv, CRC) != recv.check) {
				contorNAK--;
				printf(YELLOW "[RECEIVER] Initializing connection failed! Retrying...\n" RESETCOLOR);
				pack = make_pack(recv.seq, 'N', vid);
				memset(t.payload, 0, 1400);
				memcpy(t.payload, &pack, sizeof(kermit));
				t.len = sizeof(kermit);
				send_message(&t);
			}
			else {	pack = make_pack(recv.seq, 'Y', vid);
				memset(t.payload, 0, 1400);
				memcpy(t.payload, &pack, sizeof(kermit));
				t.len = sizeof(kermit);
				send_message(&t);
			}
		}
	
	} while (((y == NULL) || (pack.type == 'N')) && (contorLOST > 0) && (contorNAK > 0));
	
	if ((contorLOST == 0) || (contorNAK == 0)) {
		printf(RED "[RECEIVER] Transmission failed!\n" RESETCOLOR); 
		return 0;
	}
	else {	RESET(contorNAK); RESET(contorLOST);
		printf(BLUE "[RECEIVER] Connection estabilished.\n" RESETCOLOR);}


	do {
		recv = receive_package(&pack);

		switch (recv.type) {

		case 'E': return 0;

		case 'F':
			memset(filename, 0, 100);
			strcpy(filename, "recv_");
			f = fopen(strcat(filename, recv.data), "w");
			printf("\n==== FILE %s ====\n\n", filename);
			break;

		case 'D': if (recv.seq != prev) {
			printf("[RECEIVER] Written %d bits, seq %d, check %d\n", recv.len, recv.seq, recv.check);
			fwrite(recv.data, 1, recv.len, f);}
			break;

		case 'Z':
			fclose(f);
			break;

		case 'B': 
			printf(      "===========================================\n");
			printf(GREEN "[RECEIVER] Transmission ended with success.\n" RESETCOLOR);
			printf(      "===========================================\n");
		
		}

		prev = recv.seq;

	} while (recv.type != 'B');


	return 0;
}
