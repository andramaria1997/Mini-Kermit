#ifndef LIB
#define LIB
#define MAXL 250
#define CRC 254 // CRC is calculated for 254 bytes (250 from data and the other 4 fields from the struct)
#define TIME 5
#define RESET(X) X = 5;
#define SOH 0x01
#define MARK 0x0d
#define RED "\x1B[31m"
#define GREEN "\x1B[32m"
#define BLUE "\x1B[34m"
#define YELLOW "\x1B[33m"
#define RESETCOLOR "\x1B[0m"

typedef struct {
    int len;
    char payload[1400];
} msg;

void init(char* remote, int remote_port);
void set_local_port(int port);
void set_remote(char* ip, int port);
int send_message(const msg* m);
int recv_message(msg* r);
msg* receive_message_timeout(int timeout); //timeout in milliseconds
unsigned short crc16_ccitt(const void *buf, int len);

typedef struct __attribute__((__packed__)) {

	char maxl;
	char time;
	char npad;
	char padc;
	char eol;
	char qctl;
	char qbin;
	char chkt;
	char rept;
	char capa;
	char r;

} sdata;

typedef struct __attribute__((__packed__)){

	unsigned char soh;
	unsigned char len;
	unsigned char seq;
	unsigned char type;
	char data[MAXL];
	unsigned short check;
	char mark;

} kermit; 


kermit make_S_pack (char type, char maxl, char time, char seq) {

    	sdata initdata;
	initdata.maxl = maxl;
	initdata.time = time;
	initdata.npad = 0;
	initdata.padc = 0;
	initdata.eol = 0x0d;
	initdata.qctl = 0;
	initdata.qbin = 0;
	initdata.chkt = 0;
	initdata.rept = 0;
	initdata.capa = 0;
	initdata.r = 0;

	kermit package;

	package.soh = SOH;
	package.len = 2;
	package.seq = seq;
	package.type = type;
	memcpy(package.data, &initdata, sizeof(sdata));
	package.check = crc16_ccitt(&package, CRC);
	package.mark = MARK;

	return package;
}

kermit make_pack (int seq, char type, char data[MAXL]) {

	kermit package;

	package.soh = SOH;
	package.len = 2;
	package.seq = seq;
	package.type = type;
	memcpy(package.data, data, MAXL);
	package.check = crc16_ccitt(&package, CRC);
	package.mark = MARK;

	return package;
}

int send_package(kermit pktt) {

	msg t, *y;
	int contorNAK, contorLOST;
	RESET(contorNAK); RESET(contorLOST);
	kermit recv;
	static int prev = -1;

		pktt.check = crc16_ccitt(&pktt, CRC);

	do {
		memset(t.payload, 0, 1400);
		memcpy(t.payload, &pktt, sizeof(kermit));
		t.len = sizeof(kermit);
		send_message(&t);

		printf("[SENDER]   Sending package %c seq %d CRC %d...\n", pktt.type, pktt.seq, pktt.check);

	    	y = receive_message_timeout(5000);

	    	if (y == NULL) {
			perror("receive error");
			printf("[SENDER]   I recieved nothing so I'm resending...\n");
			contorLOST--;
			RESET(contorNAK);
	    	} else {
			memset(&recv, 0, sizeof(kermit));
			memcpy(&recv, y->payload, y->len);

			RESET(contorLOST);

			if (recv.check == crc16_ccitt(&recv, CRC)) {

				if (recv.type == 'N') {
					pktt.seq = (recv.seq+1)%64;
					pktt.check = crc16_ccitt(&pktt, CRC);
					printf("[SENDER]   I recieved NAK %d! Resending with seq %d CRC %d...\n", recv.seq, pktt.seq, pktt.check);
					contorNAK--;
				}
				else printf (RESETCOLOR "[SENDER]   I recieved ACK seq %d.\n", recv.seq);
		    	}
			else {
				printf("[SENDER]   ACK broken. Resending...\n");
			}
		}

	}
	while (((y == NULL) || (recv.type == 'N') || (recv.seq == prev) || (recv.check != crc16_ccitt(&recv, CRC))) && (contorLOST > 0) && (contorNAK > 0));

	prev = recv.seq;

	if ((contorLOST == 0) || (contorNAK == 0))
		return -1;
	
	return (recv.seq)%64;

}


kermit receive_package(kermit *ack) {

	msg t, *y;
	int contorNAK, contorLOST, error;
	RESET(contorNAK); RESET(contorLOST);
	kermit recv, errorpack;
	char vid[MAXL];
	unsigned short crc;
	memset(vid, 0, MAXL);
	//static kermit ack = make_S_pack('Y', MAXL, TIME, 0);

	errorpack = make_pack(-1, 'E', vid);

	do {
		error = 0;
		y = NULL;
	    	y = receive_message_timeout(5000);

	    	if (y == NULL) {
			printf("[RECEIVER] Lost package error! Resending ACK %d \n", (*ack).seq);
			contorLOST--;
			RESET(contorNAK);
			if (contorLOST == 0) {printf("[RECIEVER] Transmission failed!\n"); return errorpack;}
			memset(t.payload, 0, 1400);
			memcpy(t.payload, ack, sizeof(kermit));
			t.len = sizeof(kermit);
			send_message(&t);
			error = 1;
	    	} else {
			memset(&recv, 0, sizeof(kermit));
			memcpy(&recv, y->payload, y->len);
			RESET(contorLOST);

		// calculating and verifying checksum

			printf("[RECEIVER] Checking for seq %d, recieved check: %d\n", recv.seq, recv.check);

			crc = crc16_ccitt(&recv, CRC);

			printf("[RECEIVER] Calculated check: %d.", crc);

			if (recv.check != crc) {
				printf("\n[RECEIVER] Error. Different CHECKSUM! Sending NAK %d...\n", recv.seq);
				// creating nak
				*ack = make_pack(((*ack).seq+1)%64, 'N', vid);
				// then send it
				memset(t.payload, 0, 1400);
				memcpy(t.payload, ack, sizeof(kermit));
				t.len = sizeof(kermit);
				contorNAK--;
				send_message(&t);
				if (contorNAK == 0) {printf("[RECIEVER] Transmission failed!\n"); return errorpack;}
				error = 1;
			}
			// if the CRC is alright, then ACK is sent
			else {
				if (recv.seq != ((*ack).seq+1)%64) {
					printf("\n[RECEIVER] DUPLICATE PACKAGE: recv=%d expected=%d  => DROP\n\n", recv.seq, (*ack).seq+1);
					error = 1;
					continue;
				}

				*ack = make_pack(recv.seq, 'Y', vid);
				printf("OK.\n");
				memset(t.payload, 0, 1400);
				memcpy(t.payload, ack, sizeof(kermit));
				t.len = sizeof(kermit);
				send_message(&t);
				printf("[RECEIVER] I recieved package %d %d.\n", recv.seq, recv.check);
				RESET(contorNAK);
			}

		}	
	
	} while (error);


	return recv;
}


#endif

